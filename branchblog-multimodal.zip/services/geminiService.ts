import { GoogleGenAI, Type } from "@google/genai";
import { ImageMetadata } from "../types";

// Helper to remove header from base64 string if present
const cleanBase64 = (b64: string) => {
  return b64.replace(/^data:image\/[a-z]+;base64,/, "");
};

export const analyzeImageWithGemini = async (
  base64Image: string,
  mimeType: string
): Promise<ImageMetadata> => {
  try {
    const apiKey = process.env.API_KEY;
    if (!apiKey) {
      console.warn("No API Key found for Gemini");
      return { dominantColor: '#333333', suggestedTags: [] };
    }

    const ai = new GoogleGenAI({ apiKey });
    
    const prompt = "Analyze this image. Return a JSON object with a 'dominantColor' (a hex color string representing the mood/feel) and a list of 3-5 short 'suggestedTags' describing the visual content.";

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: mimeType,
              data: cleanBase64(base64Image),
            },
          },
          { text: prompt },
        ],
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            dominantColor: { type: Type.STRING },
            suggestedTags: { 
              type: Type.ARRAY,
              items: { type: Type.STRING }
            }
          }
        }
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from Gemini");

    return JSON.parse(text) as ImageMetadata;

  } catch (error) {
    console.error("Gemini Analysis Failed:", error);
    // Fallback if API fails
    return {
      dominantColor: '#475569',
      suggestedTags: ['uploaded', 'image']
    };
  }
};
