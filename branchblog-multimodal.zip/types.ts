export interface MediaAttachment {
  type: 'image' | 'audio' | 'video';
  url: string; // Base64 or Blob URL
  name: string;
  mimeType: string;
}

export interface ImageMetadata {
  dominantColor?: string;
  suggestedTags?: string[];
}

export interface Post {
  id: number;
  title: string;
  content: string;
  author: string;
  createdAt: string;
  likes: number;
  tags: string[];
  parentId: number | null; // ID of the post this was forked from
  forks: number[]; // IDs of posts forked from this one
  coverImage?: {
    url: string;
    metadata?: ImageMetadata;
  };
  attachments: MediaAttachment[];
}

export type ViewMode = 'HOME' | 'CREATE' | 'DETAIL' | 'VISUALIZER' | 'SEARCH';

export interface PostContextType {
  posts: Post[];
  addPost: (post: Omit<Post, 'id' | 'createdAt' | 'likes' | 'forks'>) => void;
  likePost: (id: number) => void;
  forkPost: (parentId: number) => void;
  getPost: (id: number) => Post | undefined;
}
