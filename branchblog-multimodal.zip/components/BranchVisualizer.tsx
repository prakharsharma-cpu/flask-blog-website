import React, { useEffect, useRef, useState } from 'react';
import * as d3 from 'd3';
import { Post } from '../types';
import { GitGraph, ZoomIn, ZoomOut, RefreshCw } from 'lucide-react';

interface BranchVisualizerProps {
  posts: Post[];
  onNodeClick: (postId: number) => void;
}

const BranchVisualizer: React.FC<BranchVisualizerProps> = ({ posts, onNodeClick }) => {
  const svgRef = useRef<SVGSVGElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [rootId, setRootId] = useState<number>(0);

  // Identify all root posts (posts with no parent)
  const rootPosts = posts.filter(p => p.parentId === null);

  useEffect(() => {
    if (!svgRef.current || !containerRef.current || posts.length === 0) return;

    const width = containerRef.current.clientWidth;
    const height = 600;
    
    // Clear previous render
    d3.select(svgRef.current).selectAll("*").remove();

    // 1. Structure Data: Convert flat list to hierarchy
    // We only build the tree starting from the selected rootId
    // If the rootId doesn't exist (deleted), fallback to first available
    const effectiveRootId = posts.find(p => p.id === rootId) ? rootId : (rootPosts[0]?.id || 0);
    
    const buildHierarchy = (currentId: number): any => {
        const post = posts.find(p => p.id === currentId);
        if (!post) return null;
        return {
            name: post.title,
            id: post.id,
            data: post,
            children: post.forks.map(childId => buildHierarchy(childId)).filter(Boolean)
        };
    };

    const rootData = buildHierarchy(effectiveRootId);
    
    if (!rootData) {
        // Handle empty state
        return;
    }

    const root = d3.hierarchy(rootData);
    const treeLayout = d3.tree().size([width - 100, height - 100]);
    treeLayout(root);

    const svg = d3.select(svgRef.current)
        .attr("width", width)
        .attr("height", height)
        .append("g")
        .attr("transform", "translate(50, 50)");

    // Links
    svg.selectAll(".link")
        .data(root.links())
        .enter().append("path")
        .attr("class", "link")
        .attr("fill", "none")
        .attr("stroke", "#64748b")
        .attr("stroke-width", 2)
        .attr("d", d3.linkVertical()
            .x((d: any) => d.x)
            .y((d: any) => d.y) as any
        );

    // Nodes
    const nodes = svg.selectAll(".node")
        .data(root.descendants())
        .enter().append("g")
        .attr("class", "node")
        .attr("transform", (d: any) => `translate(${d.x},${d.y})`)
        .style("cursor", "pointer")
        .on("click", (event, d: any) => {
            onNodeClick(d.data.id);
        });

    // Node Circles
    nodes.append("circle")
        .attr("r", 20)
        .attr("fill", (d: any) => {
           const color = d.data.data.coverImage?.metadata?.dominantColor;
           return color || "#3b82f6";
        })
        .attr("stroke", "#fff")
        .attr("stroke-width", 2);

    // Node Labels (ID)
    nodes.append("text")
        .attr("dy", 5)
        .attr("text-anchor", "middle")
        .style("fill", "white")
        .style("font-size", "10px")
        .style("font-weight", "bold")
        .style("pointer-events", "none")
        .text((d: any) => d.data.id);

    // Node Titles
    nodes.append("text")
        .attr("dy", 35)
        .attr("text-anchor", "middle")
        .style("fill", "#cbd5e1")
        .style("font-size", "12px")
        .text((d: any) => d.data.name.length > 15 ? d.data.name.substring(0,12) + '...' : d.data.name);

  }, [posts, rootId]);

  return (
    <div className="bg-slate-800/50 rounded-xl p-6 border border-slate-700 shadow-xl" ref={containerRef}>
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center gap-3">
            <GitGraph className="text-blue-400" size={24} />
            <h2 className="text-2xl font-bold text-white">Branch Visualizer</h2>
        </div>
        <div className="flex items-center gap-4">
            <span className="text-sm text-slate-400">Root Post:</span>
            <select 
                value={rootId} 
                onChange={(e) => setRootId(Number(e.target.value))}
                className="bg-slate-700 text-white rounded px-3 py-1 text-sm border-none outline-none focus:ring-2 focus:ring-blue-500"
            >
                {rootPosts.map(p => (
                    <option key={p.id} value={p.id}>{p.id}: {p.title}</option>
                ))}
            </select>
        </div>
      </div>
      
      <div className="bg-slate-900 rounded-lg overflow-hidden flex justify-center items-center min-h-[600px] border border-slate-800 relative">
        {posts.length === 0 ? (
             <div className="text-slate-500">No data to visualize</div>
        ) : (
            <svg ref={svgRef}></svg>
        )}
        <div className="absolute bottom-4 right-4 text-xs text-slate-500 bg-slate-800/80 p-2 rounded">
            Click nodes to view details
        </div>
      </div>
    </div>
  );
};

export default BranchVisualizer;
