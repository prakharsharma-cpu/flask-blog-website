import React, { useState, useRef } from 'react';
import { Post, MediaAttachment, ImageMetadata } from '../types';
import { analyzeImageWithGemini } from '../services/geminiService';
import { ImagePlus, Music, Video, Loader2, Sparkles, X } from 'lucide-react';

interface CreatePostProps {
  onPublish: (postData: Omit<Post, 'id' | 'createdAt' | 'likes' | 'forks'>) => void;
  parentPost?: Post; // If forking
  onCancel: () => void;
}

const CreatePost: React.FC<CreatePostProps> = ({ onPublish, parentPost, onCancel }) => {
  const [title, setTitle] = useState(parentPost ? `${parentPost.title} (Fork)` : '');
  const [content, setContent] = useState(parentPost ? parentPost.content : '');
  const [tags, setTags] = useState<string>(parentPost ? parentPost.tags.join(', ') : '');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  
  const [coverImage, setCoverImage] = useState<{url: string, file: File, metadata?: ImageMetadata} | null>(
    parentPost?.coverImage ? { ...parentPost.coverImage, file: new File([], "placeholder") } : null
  );
  const [attachments, setAttachments] = useState<MediaAttachment[]>(parentPost?.attachments || []);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const reader = new FileReader();
      
      setIsAnalyzing(true);
      reader.onloadend = async () => {
        const base64 = reader.result as string;
        
        // Call Gemini API
        const metadata = await analyzeImageWithGemini(base64, file.type);
        
        setCoverImage({
          url: base64,
          file,
          metadata
        });
        
        // Auto-append tags
        if (metadata.suggestedTags) {
            const currentTags = tags.split(',').map(t => t.trim()).filter(Boolean);
            const newTags = [...new Set([...currentTags, ...metadata.suggestedTags])];
            setTags(newTags.join(', '));
        }

        setIsAnalyzing(false);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleMediaUpload = (e: React.ChangeEvent<HTMLInputElement>, type: 'audio' | 'video' | 'image') => {
     if (e.target.files && e.target.files[0]) {
        const file = e.target.files[0];
        const reader = new FileReader();
        reader.onloadend = () => {
            setAttachments(prev => [...prev, {
                type,
                url: reader.result as string,
                name: file.name,
                mimeType: file.type
            }]);
        };
        reader.readAsDataURL(file);
     }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onPublish({
      title,
      content,
      author: 'User', // Mock user
      tags: tags.split(',').map(t => t.trim()).filter(Boolean),
      parentId: parentPost ? parentPost.id : null,
      coverImage: coverImage ? { url: coverImage.url, metadata: coverImage.metadata } : undefined,
      attachments
    });
  };

  return (
    <div className="max-w-3xl mx-auto bg-slate-800 rounded-xl p-8 border border-slate-700 shadow-2xl animate-in fade-in slide-in-from-bottom-4 duration-300">
      <h2 className="text-3xl font-bold mb-6 text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-400">
        {parentPost ? 'Fork this Branch' : 'Start a New Branch'}
      </h2>
      
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Title */}
        <div>
          <label className="block text-sm font-medium text-slate-400 mb-2">Title</label>
          <input
            type="text"
            required
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full bg-slate-900 border border-slate-700 rounded-lg p-3 text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
            placeholder="Enter a catchy title..."
          />
        </div>

        {/* Cover Image Upload & Preview */}
        <div>
           <label className="block text-sm font-medium text-slate-400 mb-2">Cover Image (AI Analyzed)</label>
           <div className={`relative border-2 border-dashed border-slate-700 rounded-lg p-6 flex flex-col items-center justify-center transition-all ${isAnalyzing ? 'bg-slate-800/50' : 'hover:bg-slate-800/50 hover:border-blue-500'}`}>
              
              {coverImage ? (
                  <div className="relative w-full">
                      <img src={coverImage.url} alt="Cover" className="w-full h-64 object-cover rounded-md shadow-lg" />
                      <button 
                        type="button"
                        onClick={() => setCoverImage(null)}
                        className="absolute top-2 right-2 bg-red-500/80 hover:bg-red-600 p-1 rounded-full text-white transition-colors"
                      >
                          <X size={16} />
                      </button>
                      
                      {/* AI Metadata Badge */}
                      {coverImage.metadata && (
                          <div className="absolute bottom-2 left-2 flex gap-2 flex-wrap">
                              <span className="bg-black/60 backdrop-blur-sm text-white px-2 py-1 rounded text-xs flex items-center gap-1 border border-white/10">
                                  <div className="w-3 h-3 rounded-full" style={{ background: coverImage.metadata.dominantColor }}></div>
                                  {coverImage.metadata.dominantColor}
                              </span>
                          </div>
                      )}
                  </div>
              ) : (
                  <>
                    <input 
                        type="file" 
                        ref={fileInputRef}
                        accept="image/*"
                        onChange={handleImageUpload}
                        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                    />
                    <div className="text-center">
                        {isAnalyzing ? (
                            <div className="flex flex-col items-center gap-2 text-blue-400">
                                <Loader2 className="animate-spin" size={32} />
                                <span className="text-sm font-medium">Gemini is analyzing aesthetics...</span>
                            </div>
                        ) : (
                            <div className="flex flex-col items-center gap-2 text-slate-400">
                                <Sparkles size={32} className="text-purple-400" />
                                <span className="text-sm">Drop an image here or click to upload</span>
                                <span className="text-xs text-slate-500">AI will auto-detect colors and tags</span>
                            </div>
                        )}
                    </div>
                  </>
              )}
           </div>
        </div>

        {/* Content */}
        <div>
          <label className="block text-sm font-medium text-slate-400 mb-2">Content</label>
          <textarea
            required
            value={content}
            onChange={(e) => setContent(e.target.value)}
            className="w-full h-40 bg-slate-900 border border-slate-700 rounded-lg p-3 text-white focus:ring-2 focus:ring-blue-500 outline-none resize-none"
            placeholder="What's on your mind?"
          />
        </div>

        {/* Tags */}
        <div>
          <label className="block text-sm font-medium text-slate-400 mb-2">Tags</label>
          <input
            type="text"
            value={tags}
            onChange={(e) => setTags(e.target.value)}
            className="w-full bg-slate-900 border border-slate-700 rounded-lg p-3 text-white focus:ring-2 focus:ring-blue-500 outline-none"
            placeholder="tech, ai, nature..."
          />
        </div>

        {/* Attachments */}
        <div>
            <label className="block text-sm font-medium text-slate-400 mb-2">Additional Media</label>
            <div className="flex gap-4">
                 <label className="cursor-pointer flex items-center gap-2 bg-slate-700 hover:bg-slate-600 px-4 py-2 rounded-lg text-sm transition-colors">
                    <Music size={16} /> Add Audio
                    <input type="file" accept="audio/*" className="hidden" onChange={(e) => handleMediaUpload(e, 'audio')} />
                 </label>
                 <label className="cursor-pointer flex items-center gap-2 bg-slate-700 hover:bg-slate-600 px-4 py-2 rounded-lg text-sm transition-colors">
                    <Video size={16} /> Add Video
                    <input type="file" accept="video/*" className="hidden" onChange={(e) => handleMediaUpload(e, 'video')} />
                 </label>
                 <label className="cursor-pointer flex items-center gap-2 bg-slate-700 hover:bg-slate-600 px-4 py-2 rounded-lg text-sm transition-colors">
                    <ImagePlus size={16} /> Add Image
                    <input type="file" accept="image/*" className="hidden" onChange={(e) => handleMediaUpload(e, 'image')} />
                 </label>
            </div>
            {attachments.length > 0 && (
                <div className="mt-4 space-y-2">
                    {attachments.map((att, idx) => (
                        <div key={idx} className="flex items-center justify-between bg-slate-900 p-2 rounded border border-slate-700">
                            <span className="text-xs text-slate-300 truncate max-w-[200px]">{att.name}</span>
                            <span className="text-[10px] bg-slate-700 px-1 rounded uppercase text-slate-400">{att.type}</span>
                            <button type="button" onClick={() => setAttachments(attachments.filter((_, i) => i !== idx))} className="text-red-400 hover:text-red-300">
                                <X size={14} />
                            </button>
                        </div>
                    ))}
                </div>
            )}
        </div>

        {/* Actions */}
        <div className="flex gap-4 pt-4 border-t border-slate-700">
            <button 
                type="submit" 
                className="flex-1 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-semibold py-3 px-6 rounded-lg transition-all transform hover:scale-[1.02] shadow-lg shadow-blue-500/20"
            >
                Publish Branch
            </button>
            <button 
                type="button" 
                onClick={onCancel}
                className="px-6 py-3 bg-slate-700 hover:bg-slate-600 text-white rounded-lg transition-colors"
            >
                Cancel
            </button>
        </div>
      </form>
    </div>
  );
};

export default CreatePost;