import React, { useState, useMemo, useContext, createContext } from 'react';
import { 
  Home, 
  PlusCircle, 
  GitGraph, 
  Search, 
  Heart, 
  GitFork, 
  Calendar,
  Eye,
  Menu,
  X,
  Music,
  Video as VideoIcon,
  Image as ImageIcon
} from 'lucide-react';
import CreatePost from './components/CreatePost';
import BranchVisualizer from './components/BranchVisualizer';
import { Post, ViewMode } from './types';

// --- MOCK DATA ---
const INITIAL_POSTS: Post[] = [
  {
    id: 1,
    title: "The Future of AI Art",
    content: "Generative AI is reshaping how we perceive creativity. It's not just about replacement, but augmentation.",
    author: "System",
    createdAt: new Date().toISOString(),
    likes: 42,
    tags: ["ai", "art", "future"],
    parentId: null,
    forks: [2],
    coverImage: {
      url: "https://picsum.photos/seed/aiart/800/400",
      metadata: { dominantColor: "#4f46e5", suggestedTags: ["abstract", "digital"] }
    },
    attachments: []
  },
  {
    id: 2,
    title: "Re: The Future of AI Art - Human Touch",
    content: "I agree, but the human touch remains irreplaceable in curating and directing the output.",
    author: "Artist_X",
    createdAt: new Date(Date.now() + 86400000).toISOString(),
    likes: 12,
    tags: ["discussion", "humanity"],
    parentId: 1,
    forks: [],
    coverImage: {
        url: "https://picsum.photos/seed/human/800/400",
        metadata: { dominantColor: "#e11d48", suggestedTags: ["hand", "paint"] }
    },
    attachments: []
  }
];

// --- APP ---

function App() {
  const [posts, setPosts] = useState<Post[]>(INITIAL_POSTS);
  const [view, setView] = useState<ViewMode>('HOME');
  const [selectedPostId, setSelectedPostId] = useState<number | null>(null);
  const [forkingPostId, setForkingPostId] = useState<number | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  // --- ACTIONS ---

  const handlePublish = (postData: Omit<Post, 'id' | 'createdAt' | 'likes' | 'forks'>) => {
    const newId = posts.length > 0 ? Math.max(...posts.map(p => p.id)) + 1 : 1;
    const newPost: Post = {
      ...postData,
      id: newId,
      createdAt: new Date().toISOString(),
      likes: 0,
      forks: []
    };

    // If it has a parent, update parent's forks
    if (newPost.parentId) {
      setPosts(prev => prev.map(p => 
        p.id === newPost.parentId 
          ? { ...p, forks: [...p.forks, newId] }
          : p
      ));
    }

    setPosts(prev => [newPost, ...prev]); // Add to top
    setView('HOME');
    setForkingPostId(null);
  };

  const handleLike = (id: number) => {
    setPosts(prev => prev.map(p => 
      p.id === id ? { ...p, likes: p.likes + 1 } : p
    ));
  };

  const handleFork = (post: Post) => {
    setForkingPostId(post.id);
    setView('CREATE');
  };

  const handleViewDetail = (id: number) => {
    setSelectedPostId(id);
    setView('DETAIL');
  };

  const handleSearch = (query: string) => {
    setSearchQuery(query);
  };

  // --- DERIVED STATE ---
  const filteredPosts = useMemo(() => {
    if (!searchQuery) return posts;
    const q = searchQuery.toLowerCase();
    return posts.filter(p => 
      p.title.toLowerCase().includes(q) || 
      p.content.toLowerCase().includes(q) || 
      p.tags.some(t => t.toLowerCase().includes(q))
    );
  }, [posts, searchQuery]);

  const selectedPost = useMemo(() => 
    posts.find(p => p.id === selectedPostId), 
  [posts, selectedPostId]);

  const parentPostForFork = useMemo(() => 
    posts.find(p => p.id === forkingPostId), 
  [posts, forkingPostId]);

  // --- SUB-COMPONENTS (Defined here for simplicity in single-file requirement context, usually split) ---
  
  const SidebarItem = ({ icon: Icon, label, active, onClick }: any) => (
    <button 
      onClick={onClick}
      className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200 ${
        active 
          ? 'bg-blue-600/20 text-blue-400 border border-blue-600/30' 
          : 'text-slate-400 hover:bg-slate-800 hover:text-white'
      }`}
    >
      <Icon size={20} />
      <span className="font-medium">{label}</span>
    </button>
  );

  const PostCard = ({ post, isDetail = false }: { post: Post, isDetail?: boolean }) => (
    <div className={`bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl overflow-hidden transition-all duration-300 ${!isDetail && 'hover:bg-white/10 hover:border-white/20 hover:shadow-xl hover:shadow-blue-900/10'}`}>
      {/* Header */}
      <div className="p-5 flex justify-between items-start">
        <div>
           <h3 className={`font-bold text-white mb-1 ${isDetail ? 'text-3xl' : 'text-xl'}`}>{post.title}</h3>
           <div className="flex items-center gap-2 text-xs text-slate-400">
             <span>{post.author}</span>
             <span>•</span>
             <span>{new Date(post.createdAt).toLocaleDateString()}</span>
             {post.parentId && (
                <span className="bg-slate-700/50 px-2 py-0.5 rounded text-blue-300 flex items-center gap-1">
                    <GitFork size={10} /> Fork of #{post.parentId}
                </span>
             )}
           </div>
        </div>
        {!isDetail && (
            <button 
                onClick={() => handleViewDetail(post.id)}
                className="p-2 text-slate-400 hover:text-white bg-slate-800/50 rounded-full hover:bg-blue-600 transition-colors"
            >
                <Eye size={18} />
            </button>
        )}
      </div>

      {/* Cover Image */}
      {post.coverImage && (
        <div className="relative group">
            <img 
                src={post.coverImage.url} 
                alt={post.title} 
                className={`w-full object-cover ${isDetail ? 'h-[400px]' : 'h-48'}`} 
            />
            {post.coverImage.metadata?.dominantColor && (
                <div 
                    className="absolute top-0 inset-x-0 h-1" 
                    style={{ backgroundColor: post.coverImage.metadata.dominantColor, boxShadow: `0 0 20px ${post.coverImage.metadata.dominantColor}` }}
                />
            )}
            <div className="absolute bottom-2 left-2 flex gap-1">
                {post.tags.map(tag => (
                    <span key={tag} className="text-[10px] bg-black/60 backdrop-blur-md text-white px-2 py-1 rounded-full border border-white/10">
                        #{tag}
                    </span>
                ))}
            </div>
        </div>
      )}

      {/* Content */}
      <div className="p-5">
        <p className={`text-slate-300 leading-relaxed ${!isDetail && 'line-clamp-3'}`}>
            {post.content}
        </p>

        {/* Attachments (Detail View Only) */}
        {isDetail && post.attachments.length > 0 && (
            <div className="mt-6 space-y-4">
                <h4 className="text-sm font-semibold text-slate-400 uppercase tracking-wider mb-2">Attachments</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {post.attachments.map((att, idx) => (
                        <div key={idx} className="bg-slate-900/50 rounded-lg overflow-hidden border border-slate-700">
                            {att.type === 'image' && <img src={att.url} alt={att.name} className="w-full h-48 object-cover"/>}
                            {att.type === 'audio' && (
                                <div className="p-4 flex flex-col gap-2">
                                    <div className="flex items-center gap-2 text-blue-400"><Music size={16}/> {att.name}</div>
                                    <audio controls src={att.url} className="w-full h-8" />
                                </div>
                            )}
                            {att.type === 'video' && (
                                <div className="p-0">
                                     <video controls src={att.url} className="w-full h-48 bg-black" />
                                     <div className="p-2 text-xs text-slate-400 flex items-center gap-2"><VideoIcon size={14}/> {att.name}</div>
                                </div>
                            )}
                        </div>
                    ))}
                </div>
            </div>
        )}
      </div>

      {/* Footer Actions */}
      <div className="px-5 py-4 bg-black/20 border-t border-white/5 flex items-center justify-between">
         <div className="flex gap-4">
            <button 
                onClick={() => handleLike(post.id)}
                className="flex items-center gap-1.5 text-sm text-slate-400 hover:text-pink-500 transition-colors group"
            >
                <Heart size={16} className={post.likes > 0 ? "fill-pink-500 text-pink-500" : "group-hover:scale-110 transition-transform"} />
                <span>{post.likes}</span>
            </button>
            <button 
                onClick={() => handleFork(post)}
                className="flex items-center gap-1.5 text-sm text-slate-400 hover:text-blue-400 transition-colors"
            >
                <GitFork size={16} />
                <span>Fork ({post.forks.length})</span>
            </button>
         </div>
         {isDetail && (
             <button 
                onClick={() => setView('VISUALIZER')} 
                className="text-xs text-slate-500 hover:text-white flex items-center gap-1"
             >
                 <GitGraph size={14} /> View Graph
             </button>
         )}
      </div>
    </div>
  );

  return (
    <div className="min-h-screen flex text-slate-100 selection:bg-blue-500/30">
      {/* Mobile Menu Button */}
      <button 
        onClick={() => setIsSidebarOpen(!isSidebarOpen)}
        className="lg:hidden fixed top-4 right-4 z-50 p-2 bg-slate-800 rounded-md shadow-lg"
      >
        {isSidebarOpen ? <X size={24} /> : <Menu size={24} />}
      </button>

      {/* Sidebar */}
      <aside className={`fixed inset-y-0 left-0 z-40 w-64 bg-slate-900 border-r border-slate-800 transform transition-transform duration-300 ease-in-out lg:translate-x-0 ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="p-6">
          <div className="flex items-center gap-3 mb-10">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center shadow-lg shadow-blue-500/20">
              <GitGraph className="text-white" size={24} />
            </div>
            <h1 className="text-xl font-bold tracking-tight">BranchBlog</h1>
          </div>

          <nav className="space-y-2">
            <SidebarItem icon={Home} label="Home Feed" active={view === 'HOME'} onClick={() => { setView('HOME'); setSearchQuery(''); }} />
            <SidebarItem icon={PlusCircle} label="Create Post" active={view === 'CREATE'} onClick={() => { setForkingPostId(null); setView('CREATE'); }} />
            <SidebarItem icon={GitGraph} label="Visualizer" active={view === 'VISUALIZER'} onClick={() => setView('VISUALIZER')} />
            <SidebarItem icon={Search} label="Search" active={view === 'SEARCH'} onClick={() => setView('SEARCH')} />
          </nav>
        </div>

        <div className="absolute bottom-0 w-full p-6 border-t border-slate-800">
           <div className="bg-slate-800/50 rounded-lg p-4">
              <h4 className="text-xs font-semibold text-slate-500 uppercase mb-2">Stats</h4>
              <div className="flex justify-between text-sm text-slate-300">
                  <span>Total Posts</span>
                  <span className="font-mono">{posts.length}</span>
              </div>
              <div className="flex justify-between text-sm text-slate-300">
                  <span>Forks</span>
                  <span className="font-mono">{posts.reduce((acc, p) => acc + p.forks.length, 0)}</span>
              </div>
           </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className={`flex-1 transition-all duration-300 lg:ml-64 p-6 lg:p-10 max-w-[1600px] mx-auto`}>
        
        {/* Top Bar (Contextual) */}
        <div className="flex justify-between items-center mb-8">
            <div>
                 <h2 className="text-2xl font-bold text-white">
                    {view === 'HOME' && 'Latest Branches'}
                    {view === 'CREATE' && 'Studio'}
                    {view === 'DETAIL' && 'Thread View'}
                    {view === 'VISUALIZER' && 'Global Map'}
                    {view === 'SEARCH' && 'Explore'}
                 </h2>
                 <p className="text-slate-400 text-sm mt-1">
                    {view === 'HOME' && 'Discover the latest multimodal conversations.'}
                    {view === 'VISUALIZER' && 'Visualize how ideas branch and evolve.'}
                 </p>
            </div>
            {view === 'HOME' && (
                <button 
                    onClick={() => setView('CREATE')}
                    className="hidden sm:flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white px-4 py-2 rounded-full font-medium transition-all shadow-lg shadow-blue-600/20"
                >
                    <PlusCircle size={18} /> New Post
                </button>
            )}
        </div>

        {/* View Routing */}
        <div className="min-h-[500px]">
            {view === 'HOME' && (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {posts.sort((a,b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()).map(post => (
                        <PostCard key={post.id} post={post} />
                    ))}
                </div>
            )}

            {view === 'SEARCH' && (
                <div className="space-y-8">
                    <div className="relative max-w-2xl">
                        <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-slate-400" />
                        <input 
                            type="text" 
                            placeholder="Search by keyword, tag, or author..." 
                            className="w-full bg-slate-800 border-none rounded-2xl py-4 pl-12 pr-4 text-lg text-white placeholder-slate-500 focus:ring-2 focus:ring-blue-500 outline-none"
                            value={searchQuery}
                            onChange={(e) => handleSearch(e.target.value)}
                            autoFocus
                        />
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {filteredPosts.length > 0 ? (
                            filteredPosts.map(post => <PostCard key={post.id} post={post} />)
                        ) : (
                            <div className="col-span-full text-center py-20 text-slate-500">
                                No results found for "{searchQuery}"
                            </div>
                        )}
                    </div>
                </div>
            )}

            {view === 'CREATE' && (
                <CreatePost 
                    onPublish={handlePublish} 
                    parentPost={parentPostForFork} 
                    onCancel={() => { setView('HOME'); setForkingPostId(null); }}
                />
            )}

            {view === 'DETAIL' && selectedPost && (
                <div className="max-w-4xl mx-auto space-y-6">
                    <button 
                        onClick={() => setView('HOME')} 
                        className="text-slate-400 hover:text-white flex items-center gap-2 mb-4"
                    >
                        ← Back to Feed
                    </button>
                    <PostCard post={selectedPost} isDetail={true} />
                </div>
            )}

            {view === 'VISUALIZER' && (
                <BranchVisualizer 
                    posts={posts} 
                    onNodeClick={(id) => { setSelectedPostId(id); setView('DETAIL'); }}
                />
            )}
        </div>
      </main>
    </div>
  );
}

export default App;
